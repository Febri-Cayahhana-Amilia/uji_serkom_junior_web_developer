-- ============================================================
-- Batik Kirana Nusantara — Skema Database (PostgreSQL)
-- Jalankan seluruh isi file ini di pgAdmin Query Tool pada
-- database "batik_kirana" yang sudah kamu buat.
-- ============================================================

-- Hapus dulu kalau sudah pernah dibuat, biar bisa dijalankan ulang
DROP TABLE IF EXISTS detail_pesanan;
DROP TABLE IF EXISTS pesanan;
DROP TABLE IF EXISTS pesan_kontak;
DROP TABLE IF EXISTS produk;
DROP TABLE IF EXISTS kategori;
DROP TABLE IF EXISTS admin;

-- ------------------------------------------------------------
-- Tabel kategori
-- ------------------------------------------------------------
CREATE TABLE kategori (
    id_kategori   SERIAL PRIMARY KEY,
    nama_kategori VARCHAR(100) NOT NULL UNIQUE
);

-- ------------------------------------------------------------
-- Tabel produk
-- ------------------------------------------------------------
CREATE TABLE produk (
    id_produk    SERIAL PRIMARY KEY,
    id_kategori  INTEGER NOT NULL REFERENCES kategori(id_kategori) ON DELETE RESTRICT,
    nama_produk  VARCHAR(150) NOT NULL,
    deskripsi    TEXT,
    motif        VARCHAR(100),
    harga        NUMERIC(12,2) NOT NULL CHECK (harga > 0),
    stok         INTEGER NOT NULL DEFAULT 0 CHECK (stok >= 0),
    gambar       VARCHAR(255),
    dibuat_pada  TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ------------------------------------------------------------
-- Tabel admin (login panel kelola)
-- ------------------------------------------------------------
CREATE TABLE admin (
    id_admin  SERIAL PRIMARY KEY,
    username  VARCHAR(50) NOT NULL UNIQUE,
    password  VARCHAR(255) NOT NULL  -- disimpan sebagai hash (password_hash PHP)
);

-- ------------------------------------------------------------
-- Tabel pesan_kontak (form Kontak)
-- ------------------------------------------------------------
CREATE TABLE pesan_kontak (
    id_pesan    SERIAL PRIMARY KEY,
    nama        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL,
    pesan       TEXT NOT NULL,
    dibuat_pada TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ------------------------------------------------------------
-- Tabel pesanan (transaksi / checkout)
-- ------------------------------------------------------------
CREATE TABLE pesanan (
    id_pesanan          SERIAL PRIMARY KEY,
    kode_pesanan         VARCHAR(20) NOT NULL UNIQUE,
    nama_pelanggan        VARCHAR(100) NOT NULL,
    email                VARCHAR(150) NOT NULL,
    telepon              VARCHAR(30) NOT NULL,
    alamat               TEXT NOT NULL,
    metode_pembayaran    VARCHAR(30) NOT NULL,
    total_harga           NUMERIC(12,2) NOT NULL,
    status               VARCHAR(20) NOT NULL DEFAULT 'Menunggu Pembayaran',
    dibuat_pada          TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ------------------------------------------------------------
-- Tabel detail_pesanan (item per pesanan)
-- Nama & harga produk disalin saat transaksi terjadi, supaya
-- laporan tidak berubah walau produk aslinya diedit/dihapus.
-- ------------------------------------------------------------
CREATE TABLE detail_pesanan (
    id_detail    SERIAL PRIMARY KEY,
    id_pesanan   INTEGER NOT NULL REFERENCES pesanan(id_pesanan) ON DELETE CASCADE,
    id_produk    INTEGER REFERENCES produk(id_produk) ON DELETE SET NULL,
    nama_produk  VARCHAR(150) NOT NULL,
    harga_satuan NUMERIC(12,2) NOT NULL,
    jumlah       INTEGER NOT NULL CHECK (jumlah > 0),
    subtotal     NUMERIC(12,2) NOT NULL
);

-- ============================================================
-- Data contoh
-- ============================================================

INSERT INTO kategori (nama_kategori) VALUES
('Batik Tulis'),
('Batik Cap'),
('Aksesoris');

INSERT INTO produk (id_kategori, nama_produk, deskripsi, motif, harga, stok, gambar) VALUES
(1, 'Kemeja Batik Tulis Sekar Jagad', 'Kemeja batik tulis lengan panjang dengan motif Sekar Jagad, dikerjakan tangan oleh perajin lokal menggunakan kain katun primis halus.', 'Sekar Jagad', 285000, 12, NULL),
(1, 'Dress Batik Tulis Parang Kusumo', 'Dress batik tulis motif Parang Kusumo, cocok untuk acara formal maupun semi-formal.', 'Parang Kusumo', 420000, 8, NULL),
(2, 'Kemeja Batik Cap Kawung', 'Kemeja batik cap motif Kawung klasik, bahan katun adem dan nyaman dipakai harian.', 'Kawung', 165000, 20, NULL),
(2, 'Blouse Batik Cap Mega Mendung', 'Blouse batik cap motif Mega Mendung khas pesisir, warna biru indigo yang elegan.', 'Mega Mendung', 175000, 15, NULL),
(3, 'Selendang Batik Tulis Truntum', 'Selendang batik tulis motif Truntum, lembut dan ringan, cocok untuk pelengkap busana adat.', 'Truntum', 135000, 18, NULL),
(3, 'Totebag Batik Cap Sido Mukti', 'Totebag kanvas dengan aplikasi kain batik cap motif Sido Mukti, kuat untuk penggunaan sehari-hari.', 'Sido Mukti', 95000, 25, NULL);

-- Catatan: kolom "gambar" dikosongkan (NULL) karena file foto perlu
-- diunggah lewat panel admin (admin/tambah.php atau admin/edit.php)
-- setelah data ini masuk — nama file gambar baru akan tersimpan otomatis.

-- Akun admin TIDAK dibuat di sini. Jalankan sekali:
--   http://localhost:8000/database/setup_admin.php
-- untuk membuat akun admin (username: admin, password: admin123)
-- dengan password yang sudah di-hash otomatis oleh PHP, lalu hapus
-- file setup_admin.php setelah dipakai.
