<?php
require __DIR__ . '/includes/db.php';
require __DIR__ . '/includes/keranjang.php';
$base_url = '';
$judul_halaman = 'Checkout';

$keranjang = keranjang_isi($koneksi);
$error = '';
$pesananSukses = null;

if (empty($keranjang['items']) && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: keranjang.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama_pelanggan'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telepon = trim($_POST['telepon'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');
    $metode = trim($_POST['metode_pembayaran'] ?? '');

    // ---------- Validasi form (wajib) ----------
    if ($nama === '' || $email === '' || $telepon === '' || $alamat === '' || $metode === '') {
        $error = 'Semua kolom wajib diisi.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid.';
    } elseif (!preg_match('/^[0-9+\-\s]{8,20}$/', $telepon)) {
        $error = 'Format nomor telepon tidak valid.';
    } elseif (!in_array($metode, ['Transfer Bank', 'COD (Bayar di Tempat)', 'E-Wallet'], true)) {
        $error = 'Metode pembayaran tidak valid.';
    } elseif (empty($keranjang['items'])) {
        $error = 'Keranjang belanja kamu kosong.';
    } else {
        // ---------- Cek ulang stok sebelum transaksi ----------
        foreach ($keranjang['items'] as $item) {
            if ($item['jumlah'] > $item['stok']) {
                $error = 'Stok "' . $item['nama_produk'] . '" tidak mencukupi. Sisa stok: ' . $item['stok'] . '.';
                break;
            }
        }
    }

    if ($error === '') {
        try {
            $koneksi->beginTransaction();

            $kode_pesanan = 'BKN-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));

            $stmtPesanan = $koneksi->prepare(
                "INSERT INTO pesanan (kode_pesanan, nama_pelanggan, email, telepon, alamat, metode_pembayaran, total_harga, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 'Menunggu Pembayaran') RETURNING id_pesanan"
            );
            $stmtPesanan->execute([$kode_pesanan, $nama, $email, $telepon, $alamat, $metode, $keranjang['total']]);
            $id_pesanan = $stmtPesanan->fetchColumn();

            $stmtDetail = $koneksi->prepare(
                "INSERT INTO detail_pesanan (id_pesanan, id_produk, nama_produk, harga_satuan, jumlah, subtotal)
                 VALUES (?, ?, ?, ?, ?, ?)"
            );
            $stmtStok = $koneksi->prepare("UPDATE produk SET stok = stok - ? WHERE id_produk = ? AND stok >= ?");

            foreach ($keranjang['items'] as $item) {
                $stmtDetail->execute([
                    $id_pesanan, $item['id_produk'], $item['nama_produk'],
                    $item['harga'], $item['jumlah'], $item['subtotal'],
                ]);
                $stmtStok->execute([$item['jumlah'], $item['id_produk'], $item['jumlah']]);
                if ($stmtStok->rowCount() === 0) {
                    throw new Exception('Stok "' . $item['nama_produk'] . '" baru saja habis. Silakan coba lagi.');
                }
            }

            $koneksi->commit();
            keranjang_kosongkan();

            $pesananSukses = [
                'kode_pesanan' => $kode_pesanan,
                'nama'         => $nama,
                'total'        => $keranjang['total'],
                'metode'       => $metode,
                'items'        => $keranjang['items'],
            ];
        } catch (Exception $e) {
            $koneksi->rollBack();
            $error = 'Transaksi gagal: ' . $e->getMessage();
        }
    }
}

$val_nama = $_POST['nama_pelanggan'] ?? '';
$val_email = $_POST['email'] ?? '';
$val_telepon = $_POST['telepon'] ?? '';
$val_alamat = $_POST['alamat'] ?? '';
$val_metode = $_POST['metode_pembayaran'] ?? '';

require __DIR__ . '/includes/header.php';
?>

<section class="section" style="padding-top:48px;">
  <div class="wrap">

    <?php if ($pesananSukses): ?>

      <div class="checkout-sukses">
        <h2 class="section-title">Pesanan Berhasil Dibuat 🎉</h2>
        <p class="alert alert-success">
          Terima kasih, <?= htmlspecialchars($pesananSukses['nama']) ?>! Kode pesananmu adalah
          <strong><?= htmlspecialchars($pesananSukses['kode_pesanan']) ?></strong>.
          Simpan kode ini sebagai bukti transaksi.
        </p>

        <table class="admin-table" style="margin-bottom:20px;">
          <thead><tr><th>Produk</th><th>Jumlah</th><th>Subtotal</th></tr></thead>
          <tbody>
            <?php foreach ($pesananSukses['items'] as $item): ?>
              <tr>
                <td><?= htmlspecialchars($item['nama_produk']) ?></td>
                <td><?= (int)$item['jumlah'] ?></td>
                <td>Rp <?= number_format($item['subtotal'], 0, ',', '.') ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <p><strong>Metode pembayaran:</strong> <?= htmlspecialchars($pesananSukses['metode']) ?></p>
        <p style="font-size:22px; margin-bottom:28px;"><strong>Total: Rp <?= number_format($pesananSukses['total'], 0, ',', '.') ?></strong></p>

        <a href="produk.php" class="btn btn-gold">Belanja Lagi</a>
        <a href="index.php" class="btn btn-outline">Kembali ke Beranda</a>
      </div>

    <?php else: ?>

      <h2 class="section-title">Checkout</h2>
      <p class="section-sub">Lengkapi data pengiriman dan pilih metode pembayaran.</p>

      <?php if ($error): ?>
        <p class="alert alert-error"><?= htmlspecialchars($error) ?></p>
      <?php endif; ?>

      <div class="checkout-grid">
        <form method="POST" action="checkout.php" class="form-card">
          <div class="form-field">
            <label for="nama_pelanggan">Nama Lengkap</label>
            <input type="text" id="nama_pelanggan" name="nama_pelanggan" required value="<?= htmlspecialchars($val_nama) ?>">
          </div>
          <div class="form-field">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required value="<?= htmlspecialchars($val_email) ?>">
          </div>
          <div class="form-field">
            <label for="telepon">Nomor Telepon / WhatsApp</label>
            <input type="text" id="telepon" name="telepon" required placeholder="08xxxxxxxxxx" value="<?= htmlspecialchars($val_telepon) ?>">
          </div>
          <div class="form-field">
            <label for="alamat">Alamat Pengiriman</label>
            <textarea id="alamat" name="alamat" required><?= htmlspecialchars($val_alamat) ?></textarea>
          </div>
          <div class="form-field">
            <label for="metode_pembayaran">Metode Pembayaran</label>
            <select id="metode_pembayaran" name="metode_pembayaran" required>
              <option value="">— Pilih metode —</option>
              <?php foreach (['Transfer Bank', 'COD (Bayar di Tempat)', 'E-Wallet'] as $opsi): ?>
                <option value="<?= $opsi ?>" <?= $val_metode === $opsi ? 'selected' : '' ?>><?= $opsi ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <button type="submit" class="btn btn-gold">Buat Pesanan</button>
        </form>

        <div class="checkout-ringkasan">
          <h3>Ringkasan Pesanan</h3>
          <ul class="checkout-item-list">
            <?php foreach ($keranjang['items'] as $item): ?>
              <li>
                <span><?= htmlspecialchars($item['nama_produk']) ?> × <?= (int)$item['jumlah'] ?></span>
                <span>Rp <?= number_format($item['subtotal'], 0, ',', '.') ?></span>
              </li>
            <?php endforeach; ?>
          </ul>
          <div class="checkout-total-row">
            <span>Total</span>
            <strong>Rp <?= number_format($keranjang['total'], 0, ',', '.') ?></strong>
          </div>
          <a href="keranjang.php" style="font-size:14px; color:var(--soga);">← Ubah keranjang</a>
        </div>
      </div>

    <?php endif; ?>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
